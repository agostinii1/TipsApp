import React, { Component } from "react";
import {
  StyleSheet,
  Text,
  View,
  NavigatorIOS,
  TouchableHighlight,
  TouchableOpacity
} from "react-native";
import { Button } from "react-native";
import { ProgressBar } from "react-step-progress-bar";
import NavigationBar from "react-native-navbar";
//import { NavigationBar } from 'navigationbar-react-native';

export default function NavBar() {
  var b1 = false;
  var b2 = false;
  var b3 = true;
  onPress = () => {
    b2 = true;
    this.setB();
  };

  setB = () => {
    b2 = true;
  };
  const styles = StyleSheet.create({
    button: {
      backgroundColor: "transparent",
      paddingLeft: 20,
      paddingRight: 20
    },
    buttonPress: {
      backgroundColor: "transparent",
      paddingLeft: 20,
      paddingRight: 20
    },
    btext: {
      color: "#aaa",
      fontSize: 15
    },
    btextPressed: {
      color: "#f4f4f4",
      fontSize: 20,
      bottom: 5
    }
  });

  return (
    <View style={{ flexDirection: "row", bottom: 20 }}>
      <TouchableOpacity
        style={b1 ? styles.buttonPress : styles.button}
        onPress={this.onPress}
      >
        <Text style={b1 ? styles.btextPressed : styles.btext}>Placed Tips</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={b2 ? styles.buttonPress : styles.button}
        onPress={this.onPress}
      >
        <Text style={b2 ? styles.btextPressed : styles.btext}>Post Tips</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={b3 ? styles.buttonPress : styles.button}
        onPress={this.onPress}
      >
        <Text style={b3 ? styles.btextPressed : styles.btext}>Statistics</Text>
      </TouchableOpacity>
    </View>
  );
}
