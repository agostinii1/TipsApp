import React, { Component } from "react";
import {
  StyleSheet,
  Text,
  View,
  StatusBar,
  ProgressBarAndroid,
  Dimensions
} from "react-native";
import { Button } from "react-native";
import { ProgressBar } from "react-step-progress-bar";
import LinearGradient from "react-native-linear-gradient";
import * as Progress from "react-native-progress";

const ColorBar = props => {
  var { height, width } = Dimensions.get("window");
  return (
    <View style={{ padding: 10 }}>
      <View style={{ flexDirection: "row", paddingBottom: 4 }}>
        <Text style={{ color: "#e5e5e5" }}>{props.name}</Text>
        <Text
          style={{
            color: "#c4c4c4",
            left: width / 1.5,
            position: "absolute",
            fontSize: 10
          }}
        >
          {" "}
          {props.max}
        </Text>
      </View>
      <Progress.Bar
        progress={props.progress}
        width={300}
        height={7}
        color={props.color}
      />
      <Text style={{ color: "#c7c7c7", fontSize: 25 }}> {props.number}</Text>
    </View>
  );
};

export default ColorBar;
