import React, { Component } from "react";
import { StyleSheet, Text, View, StatusBar } from "react-native";
import { Button } from "react-native";
import { ProgressBar } from "react-step-progress-bar";
import LinearGradient from "react-native-linear-gradient";
import * as Progress from "react-native-progress";
import ColorBar from "./colorbar";
import UserBox from "./userbox.js";

export default function Footer() {
  return (
    <View style={{ bottom: 20 }}>
      <Text
        style={{ color: "#c4c4c4", paddingBottom: 30, fontSize: 10, right: 30 }}
      >
        Compare to Terimognish
      </Text>
      <UserBox style={{ top: 0 }} />
    </View>
  );
}
