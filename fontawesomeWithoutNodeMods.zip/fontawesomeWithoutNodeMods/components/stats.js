import React, {Component} from 'react';
import {StyleSheet, Text, View, StatusBar} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import ColorBar from './colorbar';
import PrintClass from './printClass';

class Stats extends Component {
  render() {
    return (
      <View style={{bottom: 40}}>
        <ColorBar
          color={'blue'}
          name={'Points'}
          max={100}
          value={2.6345}
          number={2.6345}
          progress={0.7}
        />
        <ColorBar
          color={'red'}
          name={'Total Tips'}
          max={300}
          value={142}
          number={142}
          progress={142 / 300}
        />
        <ColorBar
          color={'green'}
          name={'Success Rate'}
          max={'100%'}
          value={'75%'}
          number={'75%'}
          progress={0.75}
        />
      </View>
    );
  }
}

export default Stats;
